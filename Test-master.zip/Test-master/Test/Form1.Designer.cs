﻿
namespace Test
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.but1 = new System.Windows.Forms.Button();
            this.but2 = new System.Windows.Forms.Button();
            this.but3 = new System.Windows.Forms.Button();
            this.Question = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.butRestart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // but1
            // 
            this.but1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.but1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.but1.Location = new System.Drawing.Point(43, 56);
            this.but1.Name = "but1";
            this.but1.Size = new System.Drawing.Size(436, 32);
            this.but1.TabIndex = 0;
            this.but1.Tag = "1";
            this.but1.Text = "процессор, звуковая карта, видеокарта, монитор, клавиатура;";
            this.but1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.but1.UseVisualStyleBackColor = false;
            this.but1.Click += new System.EventHandler(this.but1_Click);
            // 
            // but2
            // 
            this.but2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.but2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.but2.Location = new System.Drawing.Point(43, 105);
            this.but2.Name = "but2";
            this.but2.Size = new System.Drawing.Size(436, 32);
            this.but2.TabIndex = 1;
            this.but2.Tag = "2";
            this.but2.Text = "монитор, клавиатура, материнская плата, процессор;";
            this.but2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.but2.UseVisualStyleBackColor = false;
            this.but2.Click += new System.EventHandler(this.but2_Click);
            // 
            // but3
            // 
            this.but3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.but3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.but3.Location = new System.Drawing.Point(43, 159);
            this.but3.Name = "but3";
            this.but3.Size = new System.Drawing.Size(436, 32);
            this.but3.TabIndex = 2;
            this.but3.Tag = "3";
            this.but3.Text = "процессор, ОП, внешняя память, монитор, клавиатура;";
            this.but3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.but3.UseVisualStyleBackColor = false;
            this.but3.Click += new System.EventHandler(this.but3_Click);
            // 
            // Question
            // 
            this.Question.AutoSize = true;
            this.Question.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Question.Location = new System.Drawing.Point(12, 9);
            this.Question.Name = "Question";
            this.Question.Size = new System.Drawing.Size(489, 23);
            this.Question.TabIndex = 3;
            this.Question.Text = "1/6. Основные компоненты вычислительной системы:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(157, 235);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(198, 70);
            this.button1.TabIndex = 4;
            this.button1.Tag = "0";
            this.button1.Text = "Пропустить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // butRestart
            // 
            this.butRestart.BackColor = System.Drawing.Color.Yellow;
            this.butRestart.Enabled = false;
            this.butRestart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.butRestart.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.butRestart.Location = new System.Drawing.Point(157, 332);
            this.butRestart.Name = "butRestart";
            this.butRestart.Size = new System.Drawing.Size(198, 70);
            this.butRestart.TabIndex = 5;
            this.butRestart.Tag = "10";
            this.butRestart.Text = "Начать заново";
            this.butRestart.UseVisualStyleBackColor = false;
            this.butRestart.Click += new System.EventHandler(this.butRestart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 432);
            this.Controls.Add(this.butRestart);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Question);
            this.Controls.Add(this.but3);
            this.Controls.Add(this.but2);
            this.Controls.Add(this.but1);
            this.Name = "Form1";
            this.Text = "Информатика и программирование";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button but1;
        private System.Windows.Forms.Button but2;
        private System.Windows.Forms.Button but3;
        private System.Windows.Forms.Label Question;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button butRestart;
    }
}

