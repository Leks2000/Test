﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test
{
    public partial class Form1 : Form
    {
        private string[,] otvet;
        private string otv;
        private int count = 0, shag = 1;
        public Form1()
        {
            InitializeComponent();
            otvet = new string[,]
            {
                {"1/6. Основные компоненты вычислительной системы:",
                "процессор, звуковая карта, видеокарта, монитор, клавиатура;",
                "монитор, клавиатура, материнская плата, процессор;",
                "процессор, ОП, внешняя память, монитор, клавиатура;",
                "3"},
                {"2/6. Во время исполнения прикладная программа хранится:",
                "в ПЗУ;",
                "в процессоре;",
                "в оперативной памяти;",
                 "3"},
                {"3/6. Иерархию усложнения данных можно представить в виде:",
                "Бит - Байт - Поле - Запись - Файл - База Данных;",
                "Запись - Файл - Бит - Байт - База Данных - Поле;",
                "База Данных - Байт - Поле - Запись - Бит - Файл;",
                "1"},
                {"4/6. Укажите строку, содержащую неверное утверждение",
                "1 Кбайт = 1024 байт; 1 Гбайт = 1024 Мбайт;",
                "1 Мбайт это примерно миллион байт; 1 байт = 8 бит;",
                "1 Гбайт это примерно миллион байт; 1 Мбайт = 1024 Кбайт;",
                "3"},
                {"5/6. Экспоненциальное представление числа -1,84E-04 соответствует числу:",
                "-0,000184;",
                "-0,00184;",
                "-18400;",
                "1"},
                {"6/6. Текстовые данные кодируют с использованием:",
                "таблиц размещения файлов FAT, NTFS и др.;",
                "таблиц символов Windows 1251, Unicode, ASCII и др.;",
                "структурированного языка запросов SQL;",
                "2"},
            };
            Question.Text = otvet[0, 0];
            otv = otvet[0, 4];
            but1.Text = otvet[0, 1];
            but2.Text = otvet[0, 2];
            but3.Text = otvet[0, 3];

        }

        private void but2_Click(object sender, EventArgs e)
        {

            count += otv == but2.Tag ? 1 : -1;
            Validat();

        }

        private void but3_Click(object sender, EventArgs e)
        {
           count += otv == but3.Tag ? 1 : -1;
           Validat();
        }

        private void but1_Click(object sender, EventArgs e)
        {

            count += otv == but1.Tag ? 1 : -1;
            Validat();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Validat();
        }

        private void butRestart_Click(object sender, EventArgs e)
        {
            shag = 1; 
            Question.Text = otvet[0, 0];
            otv = otvet[0, 4];
            but1.Text = otvet[0, 1];
            but2.Text = otvet[0, 2];
            but3.Text = otvet[0, 3];
            count = 0;
            but1.Enabled = true;
            but2.Enabled = true;
            but3.Enabled = true;
            button1.Enabled = true;


        }

        public void Validat()
        {
            if (shag < 6)
            {
                Question.Text = otvet[shag, 0];
                otv = otvet[shag, 4];
                but1.Text = otvet[shag, 1];
                but2.Text = otvet[shag, 2];
                but3.Text = otvet[shag, 3];
                shag++;
            }
            else
            {
                Question.Text = $"Конец теста. Вы набрали: {count}/6";
                but1.Enabled = false;
                but2.Enabled = false;
                but3.Enabled = false; 
                button1.Enabled = false;
                butRestart.Enabled = true;
            }
        }
    }
}
